# Core Bot
A generator bot made in python

This bot was made to be a public generator bot but because of discord, our growth had to stop at 100 servers so decided to release the source code

I hope you enjoy

Join the support server if u need help:
[discord](https://discord.gg/cuB4ahGEBM)

# How To Use?
Install the requirements

```pip install -r requirements.txt```

Change the token in the token.txt file

Done